#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>
int main(void *arg)
{  
    int num = *(int*)arg;
    // getpid() :����ID   pthread_self() :�߳�ID  syscall(SYS_gettid):�̵߳�PID
    printf("thread:int %ld main process, the tid=%ld,pid=%ld\n", getpid(), pthread_self(), syscall(SYS_gettid));
    printf("thread%d return\n");
    return 0;
}