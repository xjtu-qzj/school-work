#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
int global = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int global = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
void *thread1_func()
{
    pthread_mutex_lock(&mutex);
    int i;
    for (i = 0; i < 5000; i++)
    {
        global++;
    }
    printf("global��ֵΪ%d\n", global);
    execl("./exec_pthread", "exec_pthread", 1);
    pthread_mutex_unlock(&mutex);
}
void *thread2_func()
{
    pthread_mutex_lock(&mutex);
    int i;
    for (i = 0; i < 5000; i++)
    {
        global = global --;
    }
    printf("global = %d\n", global);
    execl("/root/code/1/pthread_system_call", "pthread_system_call", 2);
    pthread_mutex_unlock(&mutex);
}


int main()
{
    int status;
    pthread_t tid_one, tid_two;
    // thread 1
    status = pthread_create(&tid_one, NULL, thread1_func, NULL);
    if (status != 0)
    { // error occured
        printf("thread1 default = %d\n", status);
        return 1;
    }
    printf("thread1 success create\n");

    // thread 2
    status = pthread_create(&tid_two, NULL, thread2_func, NULL);
    if (status != 0)
    { // error occured
        printf("thread2 default = %d\n", status);
        return 1;
    }
    
    pthread_join(tid_one, NULL);
    pthread_join(tid_two, NULL);
    pthread_mutex_destroy(&mutex);
    printf("global = %d ", global);
    return 0;
}